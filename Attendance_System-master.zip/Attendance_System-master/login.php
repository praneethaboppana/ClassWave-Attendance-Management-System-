<?php
if (isset($_POST['login'])) {
    include 'header/db.php';
    $user_name = $_POST['username'];
    $passwd = $_POST['password'];

    // Use prepared statements to prevent SQL injection
    $stmt = $con->prepare("SELECT * FROM login WHERE user_name = ?");
    $stmt->bind_param("s", $user_name);
    $stmt->execute();
    $result = $stmt->get_result();
    $result_check = $result->num_rows;
    $row_pass = $result->fetch_assoc();

    if ($result_check < 1) {
        echo "<script>alert('User not found');</script>";
        echo "<script>window.location.href='login.html';</script>";
        exit();
    } else {
        $temp_pass = $row_pass['pass_wd'];
        if ($passwd === $temp_pass) {
            session_start();
            $_SESSION["user_id"] = $user_name;
            if ($row_pass['teach_or_std'] == '1') {
                header("Location: teacher.php");
            } else {
                header("Location: student.php");
            }
            exit();
        } else {
            echo "<script>alert('Incorrect password');</script>";
            echo "<script>window.location.href='login.html';</script>";
        }
    }

    $stmt->close();
    $con->close();
}
?>
