<?php
$server_name='localhost';
$db_user='moulika';
$db_passwd='123456';
$database_name='attendance_mang_system';

$con=mysqli_connect($server_name,$db_user,$db_passwd,$database_name);

?>