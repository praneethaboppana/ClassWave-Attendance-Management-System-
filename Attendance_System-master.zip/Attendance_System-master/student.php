<?php
session_start();
$users_name = $_SESSION["user_id"];
include 'login.php';
include_once 'header/db.php';

// Retrieve student ID from the database for the current user
$fetch_std_id_sql = "SELECT user_id FROM login WHERE user_name = '$users_name'";
$fetch_std_id_sqldata = mysqli_query($con, $fetch_std_id_sql);
$fetch_std_id = mysqli_fetch_array($fetch_std_id_sqldata);
$std_id = $fetch_std_id['user_id'];

// Set default date range (e.g., start of the year to today)
$start_date = isset($_POST['start_date']) ? $_POST['start_date'] : date('Y-01-01');
$end_date = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-d');

// Define periods per day
$periods_per_day = 7; // Number of periods per day

// Retrieve attendance details for the given date range
$fetch_std_attendance_sql = "
    SELECT att_date, period, att_prs_abs 
    FROM attendance 
    WHERE std_id = '$std_id' AND att_date BETWEEN '$start_date' AND '$end_date'
    ORDER BY att_date, period";
$fetch_std_attendance_result = mysqli_query($con, $fetch_std_attendance_sql);

// Initialize variables
$attendance_data = [];
$attendance_periods = [];

// Generate date range and default to 'NA' if no attendance recorded
$period = new DatePeriod(
    new DateTime($start_date),
    new DateInterval('P1D'),
    (new DateTime($end_date))->modify('+1 day')
);

foreach ($period as $date) {
    $formatted_date = $date->format('Y-m-d');
    $day_of_week = $date->format('N'); // 'N' gives 1 (for Monday) through 7 (for Sunday)

    // Skip Sundays (7) and non-working days if any
    if ($day_of_week == 7 /* Add additional non-working day conditions here if needed */) {
        continue;
    }

    $attendance_data[$formatted_date] = array_fill(1, $periods_per_day, 'NA');
}

// Fill attendance data
while ($fetch_std_attendance = mysqli_fetch_assoc($fetch_std_attendance_result)) {
    $date = $fetch_std_attendance['att_date'];
    $period_number = $fetch_std_attendance['period'];
    if (isset($attendance_data[$date])) {
        $attendance_data[$date][$period_number] = $fetch_std_attendance['att_prs_abs'] == '1' ? 'P' : 'A';
    }
}

// Calculate total working days in the selected date range
$total_working_days = 0;
foreach ($attendance_data as $date => $periods_attendance) {
    $day_of_week = (new DateTime($date))->format('N');
    // Count only working days (not Sunday or any other non-working day)
    if ($day_of_week != 7 /* Add additional non-working day conditions here if needed */) {
        $total_working_days++;
    }
}

// Calculate attendance
$total_periods_attended = 0;
$total_periods_possible = 0;

foreach ($attendance_data as $date => $periods_attendance) {
    foreach ($periods_attendance as $status) {
        if ($status === 'P' || $status === 'A') {
            $total_periods_possible++;
            if ($status === 'P') {
                $total_periods_attended++;
            }
        }
    }
}

// Ensure division by zero is handled
$attendance_percentage = $total_periods_possible > 0 
    ? ($total_periods_attended / $total_periods_possible) * 100
    : 0;

$required_periods = 0;
$required_days = 0;

if ($total_periods_possible > 0) {
    // Calculate the number of periods needed to reach 75% attendance
    $required_percentage = 75;
    $required_periods = ceil(($required_percentage / 100) * $total_periods_possible) - $total_periods_attended;
    $required_periods = max($required_periods, 0);

    // Calculate required days to reach 75% (assuming maximum periods per day)
    $required_days = ceil($required_periods / $periods_per_day);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Student Attendance Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e3f2fd; /* Light Blue Background */
            color: #343a40;
        }
        .container {
            margin: 50px auto;
            padding: 20px;
            max-width: 800px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h3 {
            text-align: center;
            color: #0277bd; /* Dark Blue for headings */
        }
        form {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }
        label {
            font-weight: bold;
            color: #0288d1; /* Medium Blue for labels */
        }
        input[type="date"] {
            padding: 5px;
            font-size: 14px;
            border: 1px solid #03a9f4;
            border-radius: 4px;
            background-color: #b3e5fc; /* Light Cyan for input background */
            color: #01579b;
        }
        button {
            padding: 8px 16px;
            font-size: 14px;
            color: #ffffff;
            background-color: #43a047; /* Green for buttons */
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #388e3c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #cfd8dc;
        }
        th {
            background-color: #4caf50; /* Green for table headers */
            color: #ffffff;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        tr:nth-child(even) {
            background-color: #e0f7fa; /* Light Cyan for even rows */
        }
        tr:nth-child(odd) {
            background-color: #ffffff;
        }
        tr:hover {
            background-color: #c8e6c9; /* Light Green for row hover */
        }
        td.P {
            background-color: #c8e6c9; /* Light Green for Present */
            color: #2e7d32;
            font-weight: bold;
        }
        td.A {
            background-color: #ffcdd2; /* Light Red for Absent */
            color: #c62828;
            font-weight: bold;
        }
        td.NA {
            background-color: #eceff1; /* Light Gray for Not Available */
            color: #607d8b;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Form for selecting date range -->
        <form method="post">
            <label for="start_date">Start Date:</label>
            <input type="date" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
            <label for="end_date">End Date:</label>
            <input type="date" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
            <button type="submit">Show Attendance</button>
        </form>

        <h3>Attendance Percentage: <?php echo round($attendance_percentage, 2); ?>%</h3>
        <h3>Number of additional days needed to reach 75%: <?php echo $required_days; ?></h3>

        <table>
            <tr>
                <th>Date</th>
                <?php for ($i = 1; $i <= $periods_per_day; $i++): ?>
                    <th>Period <?php echo $i; ?></th>
                <?php endfor; ?>
            </tr>
            <?php
            // Display attendance for working days only
            foreach ($attendance_data as $date => $periods_attendance) {
                $day_of_week = (new DateTime($date))->format('N');
                // Display only if it's a working day (not Sunday or any other non-working day)
                if ($day_of_week != 7 /* Add additional non-working day conditions here if needed */) {
                    echo '<tr><td>' . $date . '</td>';
                    foreach ($periods_attendance as $status) {
                        echo '<td class="' . $status . '">' . $status . '</td>';
                    }
                    echo '</tr>';
                }
            }
            ?>
        </table>
    </div>
</body>
</html>
