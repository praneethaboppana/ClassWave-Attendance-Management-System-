<?php
session_start();
include 'header/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$users_name = $_SESSION["user_id"];

// Fetch the teacher ID and name based on the logged-in user
$fetch_teach_id_sql = "SELECT user_id, user_name FROM login WHERE user_name=?";
$stmt = $con->prepare($fetch_teach_id_sql);
$stmt->bind_param("s", $users_name);
$stmt->execute();
$result = $stmt->get_result();
$fetch_teach_id = $result->fetch_assoc();
$teach_id = $fetch_teach_id['user_id'];
$teach_name = $fetch_teach_id['user_name'];

// Fetch all class IDs and sections (now class_identifier)
$class_id_sql = "SELECT class.cls_id, class.cls_name, class.class_identifier FROM class";
$class_id_sqlresult = $con->query($class_id_sql);

// Check if the query executed successfully
if (!$class_id_sqlresult) {
    die("Query failed: " . $con->error);
}

$attendance_marked = false; // Flag to check if attendance has been marked
$attendance_already_marked = false; // Flag to check if attendance is already marked
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Attendance Entry</title>
</head>
<body>
<form method="get" action="">
    <table>
        <tr>
           <td>Choose the class</td>
            <td>
                <select name="cls_id">
                    <?php
                    while ($class_id_data = $class_id_sqlresult->fetch_assoc()) {
                        echo "<option value=" . htmlspecialchars($class_id_data['cls_id']) . ">" . htmlspecialchars($class_id_data['cls_name']) . "</option>";
                    }
                    ?>
                </select>
            </td>
            <td>Select Section</td>
            <td>
                <select name="class_identifier">
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                </select>
            </td>
            <td>Select Period</td>
            <td>
                <select name="period">
                    <?php
                    for ($i = 1; $i <= 7; $i++) {
                        echo "<option value='$i'>$i</option>";
                    }
                    ?>
                </select>
            </td>
            <td><input type="submit" id="cls_submit" name="cls_submit" value="Submit"></td>
        </tr>
    </table>
</form>

<?php
if (isset($_GET['cls_submit'])) {
    $class_id = $_GET['cls_id'];
    $class_identifier = $_GET['class_identifier'];
    $period = $_GET['period'];

    // Fetch student details based on the selected class and identifier
    $student_details_sqlstmt = "SELECT Students.std_id, Students.std_name FROM Students WHERE Students.class_id=? AND Students.class_identifier=?";
    $stmt = $con->prepare($student_details_sqlstmt);
    $stmt->bind_param("ss", $class_id, $class_identifier);
    $stmt->execute();
    $student_details_sqldata = $stmt->get_result();

    echo "<form method='post' action=''>";
    echo "<input type='hidden' name='cls_id' value='$class_id'>";
    echo "<input type='hidden' name='class_identifier' value='$class_identifier'>";
    echo "<input type='hidden' name='period' value='$period'>";
    echo "<table>";
    while ($students = $student_details_sqldata->fetch_assoc()) {
        echo "<tr><td>" . htmlspecialchars($students['std_id']) . "</td><td>" . htmlspecialchars($students['std_name']) . "</td><td><input type='checkbox' name='std_list[]' value='" . htmlspecialchars($students['std_id']) . "' checked></td></tr>";
    }
    echo "<tr><td colspan=2><input type='submit' value='Submit' name='att_submit'></td></tr>";
    echo "</table>";
    echo "</form>";
}
?>

<?php
if (isset($_POST['att_submit'])) {
    $checked_abs_or_prs = isset($_POST['std_list']) ? $_POST['std_list'] : [];
    $class_id = $_POST['cls_id'];
    $class_identifier = $_POST['class_identifier'];
    $period = $_POST['period'];

    // Check if attendance has already been marked for the same date, class_identifier, and period
    $check_attendance_sql = "SELECT COUNT(*) as count FROM attendance WHERE cls_id=? AND class_identifier=? AND att_date=CURRENT_DATE AND period=?";
    $stmt = $con->prepare($check_attendance_sql);
    $stmt->bind_param("iss", $class_id, $class_identifier, $period);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row['count'] > 0) {
        $attendance_already_marked = true;
    } else {
        // Fetch all student IDs for the class and identifier
        $all_std_id = [];
        $student_details_sqlstmt = "SELECT Students.std_id FROM Students WHERE Students.class_id=? AND Students.class_identifier=?";
        $stmt = $con->prepare($student_details_sqlstmt);
        $stmt->bind_param("ss", $class_id, $class_identifier);
        $stmt->execute();
        $student_details_sqldata = $stmt->get_result();
        while ($students = $student_details_sqldata->fetch_assoc()) {
            $all_std_id[] = $students['std_id'];
        }

        // Determine absent students
        $not_present_checker = array_diff($all_std_id, $checked_abs_or_prs);
        $not_pres_merg = array_merge([], $not_present_checker);

        // Insert present students
        foreach ($checked_abs_or_prs as $std_id) {
            $sql_prs_ins = "INSERT INTO attendance (att_date, att_prs_abs, cls_id, std_id, teach_id, class_identifier, period) VALUES (CURRENT_DATE, 1, ?, ?, ?, ?, ?)";
            $stmt = $con->prepare($sql_prs_ins);
            $stmt->bind_param("isisi", $class_id, $std_id, $teach_id, $class_identifier, $period);
            $stmt->execute();
        }

        // Insert absent students
        foreach ($not_pres_merg as $std_id) {
            $sql_abs_ins = "INSERT INTO attendance (att_date, att_prs_abs, cls_id, std_id, teach_id, class_identifier, period) VALUES (CURRENT_DATE, 0, ?, ?, ?, ?, ?)";
            $stmt = $con->prepare($sql_abs_ins);
            $stmt->bind_param("iiisi", $class_id, $std_id, $teach_id, $class_identifier, $period);
            $stmt->execute();
        }

        // Set the flag to true after marking attendance
        $attendance_marked = true;
    }
}

// Display confirmation message if attendance has been marked
if ($attendance_marked) {
    echo "<p style='color: green;'>Attendance has been successfully marked.</p>";
} elseif ($attendance_already_marked) {
    echo "<p style='color: red;'>Attendance for the selected class and period has already been marked.</p>";
}
?>

<!-- Cumulative Attendance Form -->
<form method="get" action="">
    <table>
        <tr>
            <td>Select Start Date</td>
            <td><input type="date" name="start_date" required></td>
        </tr>
        <tr>
            <td>Select End Date</td>
            <td><input type="date" name="end_date" required></td>
        </tr>
        <tr>
            <td>Select Period</td>
            <td>
                <select name="period" required>
                    <option value="0">All Periods</option>
                    <?php
                    for ($i = 1; $i <= 7; $i++) {
                        echo "<option value='$i'>$i</option>";
                    }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Select Class</td>
            <td>
                <select name="cls_id" required>
                    <option value="0">All Classes</option>
                    <?php
                    $class_id_sqlresult->data_seek(0); // Reset pointer to beginning
                    while ($class_id_data = $class_id_sqlresult->fetch_assoc()) {
                        echo "<option value=" . htmlspecialchars($class_id_data['cls_id']) . ">" . htmlspecialchars($class_id_data['cls_name']) . "</option>";
                    }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Select Section</td>
            <td>
                <select name="class_identifier" required>
                    <option value="0">All Sections</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                </select>
            </td>
        </tr>
        <tr>
            <td><input type="submit" id="cumulative_submit" name="cumulative_submit" value="Generate Report"></td>
        </tr>
    </table>
</form>

<?php
if (isset($_GET['cumulative_submit'])) {
    $start_date = $_GET['start_date'];
    $end_date = $_GET['end_date'];
    $period = $_GET['period'];
    $class_id = $_GET['cls_id'];
    $section = $_GET['class_identifier'];

    // Fetch class names for selected classes and sections
    if ($class_id != 0) {
        $class_names_sql = "SELECT GROUP_CONCAT(cls_name SEPARATOR ', ') as class_names FROM class WHERE cls_id = ?";
        $stmt = $con->prepare($class_names_sql);
        $stmt->bind_param("i", $class_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $class_names = $result->fetch_assoc()['class_names'];
    } else {
        $class_names = "All Classes";
    }

    // Fetch attendance data for selected date range, period, class, and section
    // Fetch attendance data for selected date range, period, class, and section
    $attendance_sql = "SELECT class.cls_name, Students.class_identifier, attendance.att_date, attendance.period, Students.std_id, Students.std_name, attendance.att_prs_abs 
    FROM attendance 
    INNER JOIN Students ON attendance.std_id = Students.std_id 
    INNER JOIN class ON attendance.cls_id = class.cls_id 
    WHERE attendance.att_date BETWEEN ? AND ? 
    AND (attendance.period = ? OR ? = 0) 
    AND (attendance.cls_id = ? OR ? = 0) 
    AND (Students.class_identifier = ? OR ? = '0') 
    ORDER BY class.cls_name, Students.std_id, attendance.att_date, attendance.period";

    $stmt = $con->prepare($attendance_sql);
    $stmt->bind_param("ssiiiiss", $start_date, $end_date, $period, $period, $class_id, $class_id, $section, $section);
    $stmt->execute();
    $attendance_result = $stmt->get_result();

    $attendance_data = [];

    // Organize attendance data by class, student, date, and period
    while ($row = $attendance_result->fetch_assoc()) {
    $attendance_data[$row['cls_name']][$row['std_id']]['std_name'] = $row['std_name'];
    $attendance_data[$row['cls_name']][$row['std_id']]['class_identifier'] = $row['class_identifier'];
    $attendance_data[$row['cls_name']][$row['std_id']]['attendance'][$row['att_date']][$row['period']] = $row['att_prs_abs'];
    }

    // Get all dates between start and end date
    $dates = [];
    $current_date = strtotime($start_date);
    $end_date_timestamp = strtotime($end_date);

    while ($current_date <= $end_date_timestamp) {
    $dates[] = date("Y-m-d", $current_date);
    $current_date = strtotime("+1 day", $current_date);
    }

    echo "<h2>Cumulative Attendance for Classes: {$class_names}<br>From: {$start_date} To: {$end_date}</h2>";
    echo "<table border='1'>";
    echo "<tr><th>Class</th><th>Section</th><th>Student ID</th><th>Student Name</th>";
    foreach ($dates as $date) {
    if ($period == 0) {
    // Display all periods if "All Periods" is selected
    foreach (range(1, 7) as $period_number) {
    echo "<th>{$date} - Period {$period_number}</th>";
    }
    } else {
    // Display only the selected period
    echo "<th>{$date} - Period {$period}</th>";
    }
    }
    echo "</tr>";

    foreach ($attendance_data as $class_name => $students_data) {
    foreach ($students_data as $std_id => $student_data) {
    echo "<tr>";
    echo "<td>{$class_name}</td>";
    echo "<td>{$student_data['class_identifier']}</td>";
    echo "<td>{$std_id}</td>";
    echo "<td>{$student_data['std_name']}</td>";
    foreach ($dates as $date) {
    if ($period == 0) {
    // Display all periods if "All Periods" is selected
    foreach (range(1, 7) as $period_number) {
    $status = isset($student_data['attendance'][$date][$period_number]) ? ($student_data['attendance'][$date][$period_number] == 1 ? 'P' : 'A') : 'NA';
    echo "<td>{$status}</td>";
    }
    } else {
    // Display only the selected period
    $status = isset($student_data['attendance'][$date][$period]) ? ($student_data['attendance'][$date][$period] == 1 ? 'P' : 'A') : 'NA';
    echo "<td>{$status}</td>";
    }
    }
    echo "</tr>";
    }
    }

    echo "</table>";

}
?>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Attendance Entry</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h2 {
            color: #333;
            text-align: center;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 20px auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 14px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
            color: #333;
        }

        td {
            background-color: #fff;
        }

        input[type="submit"], input[type="date"], select {
            padding: 8px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            background-color: #fff;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: #ffff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        select {
            width: 100%;
            padding: 8px 12px;
            margin: 8px 0;
        }

        td input[type="checkbox"] {
            margin-right: 10px;
            cursor: pointer;
        }

        .form-table {
            width: 100%;
        }

        .form-table td {
            padding: 10px;
            text-align: left;
            vertical-align: middle;
        }

        .form-table select {
            width: 95%;
        }

        .form-table input[type="date"] {
            width: 90%;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .success-message {
            color: green;
            text-align: center;
            margin-top: 20px;
            font-weight: bold;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-top: 20px;
            font-weight: bold;
        }

    </style>
</head>
<body>

<!-- Form and Table Code Here -->

</body>
</html>
