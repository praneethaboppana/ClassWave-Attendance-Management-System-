<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Register - Attendance Management System</title>
  <link rel="stylesheet" href="./css/register.css">
  <style>
    /* Additional style to make label text color white */
    label {
      color: white;
    }
  </style>
  <script>
    function showStudentFields() {
      document.getElementById('studentFields').style.display = 'block';
      document.getElementById('teacherFields').style.display = 'none';
    }

    function showTeacherFields() {
      document.getElementById('studentFields').style.display = 'none';
      document.getElementById('teacherFields').style.display = 'block';
    }
  </script>
</head>
<body style="background: black">
<div style="margin-top: 100px">
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
    <table align="center">
      <tr>
        <th colspan="2" style="text-align: center">
          <label style="color: white; font-size: 35px">Create Account</label>
        </th>
      </tr>
      <tr>
        <td>
          <label style="color: rgb(238, 230, 230)">ID:</label>
        </td>
        <td>
          <input type="text" name="id" placeholder="ID" class="tbl_des" required>
        </td>
      </tr>
      <tr>
        <td>
          <label style="color: rgb(238, 230, 230)">Username:</label>
        </td>
        <td>
          <input type="text" name="username" placeholder="Username" class="tbl_des" required>
        </td>
      </tr>
      <tr>
        <td>
          <label style="color: rgb(239, 232, 232)">Password:</label>
        </td>
        <td>
          <input type="password" name="password" placeholder="Password" class="tbl_des" required>
        </td>
      </tr>
      <tr>
        <td>
          <label style="color: rgb(239, 232, 232)">Re-enter Password:</label>
        </td>
        <td>
          <input type="password" name="repassword" placeholder="Re-enter Password" class="tbl_des" required>
        </td>
      </tr>
      <tr>
        <td colspan="2" style="text-align: center">
          <label style="color: rgb(239, 232, 232)">Role:</label><br>
          <input type="radio" name="role" value="student" onclick="showStudentFields()" required> <label style="color: white;" for="student">Student</label>
          <input type="radio" name="role" value="teacher" onclick="showTeacherFields()" required> <label style="color: white;" for="teacher">Teacher</label>
        </td>
      </tr>
      <tr id="studentFields" style="display: none;">
        <td colspan="2">
          <table>
            <tr>
              <td>
                <label style="color: rgb(238, 230, 230)">Contact No:</label>
              </td>
              <td>
                <input type="text" name="contact_no" placeholder="Contact No" class="tbl_des" pattern="\d{10}" title="Please enter a valid 10-digit mobile number" required>
              </td>
            </tr>
            <tr>
              <td>
                <label style="color: rgb(238, 230, 230)">Address:</label>
              </td>
              <td>
                <input type="text" name="address" placeholder="Address" class="tbl_des">
              </td>
            </tr>
            <tr>
              <td>
                <label style="color: rgb(238, 230, 230)">Class:</label>
              </td>
              <td>
                <select name="class_id" class="tbl_des">
                  <option value="100">A</option>
                  <option value="101">B</option>
                  <option value="102">C</option>
                  <option value="103">D</option>
                </select>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr id="teacherFields" style="display: none;">
        <td colspan="2">
          <table>
            <tr>
              <td>
                <label style="color: rgb(238, 230, 230)">Contact No:</label>
              </td>
              <td>
                <input type="text" name="contact_no" placeholder="Contact No" class="tbl_des" pattern="\d{10}" title="Please enter a valid 10-digit mobile number" required>
              </td>
            </tr>
            <tr>
              <td>
                <label style="color: rgb(238, 230, 230)">Specialisation:</label>
              </td>
              <td>
                <input type="text" name="teach_specialisation" placeholder="Specialisation" class="tbl_des">
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td colspan="2" style="text-align: center">
          <input type="submit" name="register" value="Create Account" class="register_btn">
        </td>
      </tr>
    </table>
  </form>
</div>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'header/db.php';

    // Sanitize and validate input
    function sanitize_input($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    $id = sanitize_input($_POST['id']);
    $username = sanitize_input($_POST['username']);
    $password = sanitize_input($_POST['password']);
    $repassword = sanitize_input($_POST['repassword']);
    $role = sanitize_input($_POST['role']);

    if ($password !== $repassword) {
        echo "<script>alert('Passwords do not match');</script>";
        echo "<script>window.location.href='register.php';</script>";
        exit();
    }

    if ($role == "student") {
        $contact_no = sanitize_input($_POST['contact_no']);
        $address = sanitize_input($_POST['address']);
        $class_id = sanitize_input($_POST['class_id']);

        if (strlen($contact_no) != 10 || !ctype_digit($contact_no)) {
            echo "<script>alert('Please enter a valid 10-digit mobile number');</script>";
            echo "<script>window.location.href='register.php';</script>";
            exit();
        }

        $stmt_student = $con->prepare("INSERT INTO students (std_id, std_name, std_contact, std_address, class_id) VALUES (?, ?, ?, ?, ?)");
        $stmt_student->bind_param("isssi", $id, $username, $contact_no, $address, $class_id);
        if ($stmt_student->execute()) {
            echo "<script>alert('Student record inserted successfully');</script>";
        } else {
            echo "Error inserting student record: " . $stmt_student->error;
        }
        $stmt_student->close();

        $role_value = 0; // Assuming students have login credentials
        $stmt_login = $con->prepare("INSERT INTO login (user_id, user_name, pass_wd, teach_or_std) VALUES (?, ?, ?, ?)");
        $stmt_login->bind_param("issi", $id, $username, $password, $role_value);
        if ($stmt_login->execute()) {
            echo "<script>alert('Account created successfully');</script>";
            echo "<script>window.location.href='login.php';</script>";
        } else {
            echo "Error creating account: " . $stmt_login->error;
        }
        $stmt_login->close();
    }

    if ($role == "teacher") {
        $teach_contact = sanitize_input($_POST['contact_no']);
        $teach_specialisation = sanitize_input($_POST['teach_specialisation']);

        if (strlen($teach_contact) != 10 || !ctype_digit($teach_contact)) {
            echo "<script>alert('Please enter a valid 10-digit mobile number');</script>";
            echo "<script>window.location.href='register.php';</script>";
            exit();
        }

        $stmt_teacher = $con->prepare("INSERT INTO teacher (teach_id, teach_name, teach_contact, teach_specialisation) VALUES (?, ?, ?, ?)");
        $stmt_teacher->bind_param("isss", $id, $username, $teach_contact, $teach_specialisation);
        if ($stmt_teacher->execute()) {
            echo "<script>alert('Teacher record inserted successfully');</script>";

            $role_value = 1; // Assuming teachers have login credentials
                       // Complete the login record insertion for teachers
                       $stmt_login = $con->prepare("INSERT INTO login (user_id, user_name, pass_wd, teach_or_std) VALUES (?, ?, ?, ?)");
                       $stmt_login->bind_param("issi", $id, $username, $password, $role_value);
                       if ($stmt_login->execute()) {
                           echo "<script>alert('Account created successfully');</script>";
                           echo "<script>window.location.href='login.php';</script>";
                       } else {
                           echo "Error creating account: " . $stmt_login->error;
                       }
                       $stmt_login->close();
                   } else {
                       echo "Error inserting teacher record: " . $stmt_teacher->error;
                   }
                   $stmt_teacher->close();
               }
           
               $con->close();
           }
           ?>
           