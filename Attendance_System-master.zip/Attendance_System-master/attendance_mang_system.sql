-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2024 at 09:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_mang_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `att_id` int(8) NOT NULL,
  `att_date` date NOT NULL,
  `att_prs_abs` tinyint(1) NOT NULL DEFAULT 0,
  `cls_id` int(3) NOT NULL,
  `std_id` int(11) DEFAULT NULL,
  `teach_id` int(11) DEFAULT NULL,
  `class_identifier` varchar(255) DEFAULT NULL,
  `period` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`att_id`, `att_date`, `att_prs_abs`, `cls_id`, `std_id`, `teach_id`, `class_identifier`, `period`) VALUES
(1, '2019-03-25', 1, 100, 10001, 50000, 'A', 1),
(2, '2019-03-24', 0, 100, 10001, 50000, 'A', 1),
(3, '2019-03-20', 1, 100, 10001, 50000, 'A', 1),
(4, '2024-08-20', 1, 100, 10000, 10004, 'A', 5),
(5, '2024-08-20', 1, 100, 10001, 10004, 'A', 5),
(6, '2024-08-20', 1, 100, 10002, 10004, 'A', 5),
(7, '2024-08-20', 1, 100, 10011, 10004, 'A', 5),
(8, '2024-08-20', 1, 100, 10012, 10004, 'A', 5),
(9, '2024-08-20', 1, 100, 10013, 10004, 'A', 5),
(10, '2024-08-20', 1, 100, 10015, 10004, 'A', 5),
(11, '2024-08-20', 1, 100, 10016, 10004, 'A', 5),
(12, '2024-08-20', 1, 100, 10017, 10004, 'A', 5),
(13, '2024-08-20', 1, 100, 10019, 10004, 'A', 5),
(14, '2024-08-20', 1, 100, 10020, 10004, 'A', 5),
(15, '2024-08-20', 1, 100, 10021, 10004, 'A', 5),
(16, '2024-08-20', 1, 100, 10022, 10004, 'A', 5),
(17, '2024-08-20', 1, 100, 10023, 10004, 'A', 5),
(18, '2024-08-20', 1, 100, 10025, 10004, 'A', 5),
(19, '2024-08-20', 1, 100, 10000, 10004, 'A', 6),
(20, '2024-08-20', 1, 100, 10001, 10004, 'A', 6),
(21, '2024-08-20', 1, 100, 10002, 10004, 'A', 6),
(22, '2024-08-20', 1, 100, 10011, 10004, 'A', 6),
(23, '2024-08-20', 1, 100, 10012, 10004, 'A', 6),
(24, '2024-08-20', 1, 100, 10013, 10004, 'A', 6),
(25, '2024-08-20', 1, 100, 10015, 10004, 'A', 6),
(26, '2024-08-20', 1, 100, 10016, 10004, 'A', 6),
(27, '2024-08-20', 1, 100, 10017, 10004, 'A', 6),
(28, '2024-08-20', 1, 100, 10019, 10004, 'A', 6),
(29, '2024-08-20', 1, 100, 10021, 10004, 'A', 6),
(30, '2024-08-20', 1, 100, 10022, 10004, 'A', 6),
(31, '2024-08-20', 1, 100, 10023, 10004, 'A', 6),
(32, '2024-08-20', 1, 100, 10024, 10004, 'A', 6),
(33, '2024-08-20', 1, 100, 10025, 10004, 'A', 6),
(34, '2024-08-20', 1, 100, 10000, 10004, 'A', 7),
(35, '2024-08-20', 1, 100, 10001, 10004, 'A', 7),
(36, '2024-08-20', 1, 100, 10002, 10004, 'A', 7),
(37, '2024-08-20', 1, 100, 10011, 10004, 'A', 7),
(38, '2024-08-20', 1, 100, 10012, 10004, 'A', 7),
(39, '2024-08-20', 1, 100, 10013, 10004, 'A', 7),
(40, '2024-08-20', 1, 100, 10015, 10004, 'A', 7),
(41, '2024-08-20', 1, 100, 10016, 10004, 'A', 7),
(42, '2024-08-20', 1, 100, 10019, 10004, 'A', 7),
(43, '2024-08-20', 1, 100, 10020, 10004, 'A', 7),
(44, '2024-08-20', 1, 100, 10021, 10004, 'A', 7),
(45, '2024-08-20', 1, 100, 10022, 10004, 'A', 7),
(46, '2024-08-20', 1, 100, 10023, 10004, 'A', 7),
(47, '2024-08-20', 1, 100, 10024, 10004, 'A', 7),
(48, '2024-08-20', 1, 101, 10003, 10004, 'A', 1),
(49, '2024-08-20', 1, 101, 10004, 10004, 'A', 1),
(50, '2024-08-20', 1, 101, 10003, 10004, 'A', 4),
(51, '2024-08-20', 1, 101, 10004, 10004, 'A', 4),
(52, '2024-08-20', 1, 100, 10000, 10004, 'A', 3),
(53, '2024-08-20', 1, 100, 10001, 10004, 'A', 3),
(54, '2024-08-20', 1, 100, 10002, 10004, 'A', 3),
(55, '2024-08-20', 1, 100, 10011, 10004, 'A', 3),
(56, '2024-08-20', 1, 100, 10012, 10004, 'A', 3),
(57, '2024-08-20', 1, 100, 10013, 10004, 'A', 3),
(58, '2024-08-20', 1, 100, 10015, 10004, 'A', 3),
(59, '2024-08-20', 1, 100, 10016, 10004, 'A', 3),
(60, '2024-08-20', 1, 100, 10017, 10004, 'A', 3),
(61, '2024-08-20', 1, 100, 10019, 10004, 'A', 3),
(62, '2024-08-20', 1, 100, 10020, 10004, 'A', 3),
(63, '2024-08-20', 1, 100, 10021, 10004, 'A', 3),
(64, '2024-08-20', 1, 100, 10022, 10004, 'A', 3),
(65, '2024-08-20', 1, 100, 10023, 10004, 'A', 3),
(66, '2024-08-20', 1, 100, 10024, 10004, 'A', 3),
(67, '2024-08-20', 1, 100, 10025, 10004, 'A', 3),
(68, '2024-08-20', 1, 100, 10014, 10004, 'B', 1),
(69, '2024-08-20', 1, 100, 10000, 10004, 'A', 2),
(70, '2024-08-20', 1, 100, 10001, 10004, 'A', 2),
(71, '2024-08-20', 1, 100, 10002, 10004, 'A', 2),
(72, '2024-08-20', 1, 100, 10011, 10004, 'A', 2),
(73, '2024-08-20', 1, 100, 10012, 10004, 'A', 2),
(74, '2024-08-20', 1, 100, 10013, 10004, 'A', 2),
(75, '2024-08-20', 1, 100, 10015, 10004, 'A', 2),
(76, '2024-08-20', 1, 100, 10016, 10004, 'A', 2),
(77, '2024-08-20', 1, 100, 10017, 10004, 'A', 2),
(78, '2024-08-20', 1, 100, 10020, 10004, 'A', 2),
(79, '2024-08-20', 1, 100, 10021, 10004, 'A', 2),
(80, '2024-08-20', 1, 100, 10022, 10004, 'A', 2),
(81, '2024-08-20', 1, 100, 10023, 10004, 'A', 2),
(82, '2024-08-20', 1, 100, 10024, 10004, 'A', 2),
(83, '2024-08-20', 1, 100, 10025, 10004, 'A', 2),
(84, '2024-08-20', 1, 100, 10000, 10004, 'A', 4),
(85, '2024-08-20', 1, 100, 10001, 10004, 'A', 4),
(86, '2024-08-20', 1, 100, 10002, 10004, 'A', 4),
(87, '2024-08-20', 1, 100, 10011, 10004, 'A', 4),
(88, '2024-08-20', 1, 100, 10012, 10004, 'A', 4),
(89, '2024-08-20', 1, 100, 10013, 10004, 'A', 4),
(90, '2024-08-20', 1, 100, 10015, 10004, 'A', 4),
(91, '2024-08-20', 1, 100, 10016, 10004, 'A', 4),
(92, '2024-08-20', 1, 100, 10017, 10004, 'A', 4),
(93, '2024-08-20', 1, 100, 10019, 10004, 'A', 4),
(94, '2024-08-20', 1, 100, 10020, 10004, 'A', 4),
(95, '2024-08-20', 1, 100, 10021, 10004, 'A', 4),
(96, '2024-08-20', 1, 100, 10022, 10004, 'A', 4),
(97, '2024-08-20', 1, 100, 10023, 10004, 'A', 4),
(98, '2024-08-20', 1, 100, 10024, 10004, 'A', 4),
(99, '2024-08-20', 1, 100, 10025, 10004, 'A', 4),
(100, '2024-08-20', 1, 101, 10003, 10004, 'A', 2),
(101, '2024-08-20', 1, 102, 10005, 10004, 'A', 1),
(102, '2024-08-20', 1, 101, 10003, 10004, 'A', 6),
(103, '2024-08-20', 1, 101, 10004, 10004, 'A', 6),
(104, '2024-08-20', 1, 100, 10014, 10004, 'B', 2);

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `cls_id` int(3) NOT NULL,
  `cls_name` varchar(50) NOT NULL,
  `teach_id` int(5) NOT NULL,
  `class_identifier` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`cls_id`, `cls_name`, `teach_id`, `class_identifier`) VALUES
(100, '1', 50000, 'A'),
(101, '2', 50001, 'A'),
(102, '3', 50002, 'A'),
(103, '4', 50001, 'A');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` int(5) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `pass_wd` varchar(50) NOT NULL,
  `teach_or_std` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_id`, `user_name`, `pass_wd`, `teach_or_std`) VALUES
(10000, 'John', 'passwd', 0),
(10001, 'Priya', 'passwd', 0),
(10002, 'hema', 'passwd', 0),
(10003, 'thiru', 'passwd', 0),
(10004, 'kamalesh', 'passwd', 0),
(10005, 'avinash', 'passwd', 0),
(50000, 'moni', 'passwd', 1),
(50001, 'santheep', 'passwd', 1),
(50002, 'stalin', 'passwd', 1),
(50003, 'vikas', 'passwd', 1),
(10011, 'Aarav Sharma', 'passwd', 0),
(10012, 'Priya Verma', 'passwd', 0),
(10013, 'Rahul Singh', 'passwd', 0),
(10014, 'Sneha Iyer', 'passwd', 0),
(10015, 'Arjun Reddy', 'passwd', 0),
(10016, 'Sana Khan', 'passwd', 0),
(10017, 'Rohit Rao', 'passwd', 0),
(10018, 'Lakshmi Naidu', 'passwd', 0),
(10019, 'Vikram Goud', 'passwd', 0),
(10020, 'Neha Reddy', 'passwd', 0),
(10021, 'Sai Kumar', 'passwd', 0),
(10022, 'Anjali Sharma', 'passwd', 0),
(10023, 'Kiran Babu', 'passwd', 0),
(10024, 'Pooja Rao', 'passwd', 0),
(10025, 'Siddharth Desai', 'passwd', 0),
(10026, 'Naina Agarwal', 'passwd', 0);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `std_id` int(5) NOT NULL,
  `std_name` varchar(50) NOT NULL,
  `std_contact` int(10) NOT NULL,
  `std_address` varchar(255) NOT NULL,
  `class_id` int(3) NOT NULL,
  `class_identifier` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`std_id`, `std_name`, `std_contact`, `std_address`, `class_id`, `class_identifier`) VALUES
(10000, 'John', 908976782, 'Chennai', 100, 'A'),
(10001, 'Priya', 908976782, 'Chennai', 100, 'A'),
(10002, 'Hema', 998976782, 'Chennai', 100, 'A'),
(10003, 'Thiru', 908976782, 'Chennai', 101, 'A'),
(10004, 'Kamalesh', 908576782, 'Chennai', 101, 'A'),
(10005, 'Avinash', 2147483647, 'Chennai', 102, 'A'),
(10011, 'Aarav Sharma', 2147483647, 'Delhi', 100, 'A'),
(10012, 'Priya Verma', 2147483647, 'Kolkata', 100, 'A'),
(10013, 'Rahul Singh', 2147483647, 'Bangalore', 100, 'A'),
(10014, 'Sneha Iyer', 2147483647, 'Chennai', 100, 'B'),
(10015, 'Arjun Reddy', 2147483647, 'Hyderabad', 100, 'A'),
(10016, 'Sana Khan', 2147483647, 'Hyderabad', 100, 'A'),
(10017, 'Rohit Rao', 2147483647, 'Hyderabad', 100, 'A'),
(10018, 'Lakshmi Naidu', 2147483647, 'Hyderabad', 103, 'D'),
(10019, 'Vikram Goud', 2147483647, 'Hyderabad', 100, 'A'),
(10020, 'Neha Reddy', 2147483647, 'Hyderabad', 100, 'A'),
(10021, 'Sai Kumar', 2147483647, 'Hyderabad', 100, 'A'),
(10022, 'Anjali Sharma', 2147483647, 'Hyderabad', 100, 'A'),
(10023, 'Kiran Babu', 2147483647, 'Hyderabad', 100, 'A'),
(10024, 'Pooja Rao', 2147483647, 'Hyderabad', 100, 'A'),
(10025, 'Siddharth Desai', 2147483647, 'Hyderabad', 100, 'A');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teach_id` int(5) NOT NULL,
  `teach_name` varchar(50) NOT NULL,
  `teach_contact` int(10) NOT NULL,
  `teach_specialisation` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teach_id`, `teach_name`, `teach_contact`, `teach_specialisation`) VALUES
(50000, 'Moni', 876765765, 'Tamil'),
(50001, 'Santheep', 878765765, 'English'),
(50002, 'Stalin', 976765765, 'Science'),
(50003, 'vikas', 2147483647, 'DS');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`att_id`),
  ADD KEY `att_cls_fk` (`cls_id`),
  ADD KEY `att_std_id` (`std_id`),
  ADD KEY `att_teach_fk` (`teach_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`cls_id`),
  ADD KEY `cls_taech_fk` (`teach_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`std_id`),
  ADD KEY `cls_std_fk` (`class_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teach_id`),
  ADD UNIQUE KEY `teach_contact` (`teach_contact`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `att_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `class`
--
ALTER TABLE `class`
  ADD CONSTRAINT `cls_taech_fk` FOREIGN KEY (`teach_id`) REFERENCES `teacher` (`teach_id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `cls_std_fk` FOREIGN KEY (`class_id`) REFERENCES `class` (`cls_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
