# Attendance_System
This project is about simple Attendace management system where teacher will be able to register the students attendance for a day and the students can login and view their attendance details also.

## Prerequisites
>A web server supports PHP (Apache)

>MySQL server(latest version)

## To do
* Git clone this repository to server root directory
* Go to "__header/db.php__". Change the username and password
* Import the "__Attendance_LAMP.sql__" file into your MySQL server
* Now you are ready to run

## Credits
*Praneetha B*,*Sahithi N*,*Moulika P*
